package com.abet.movil;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
