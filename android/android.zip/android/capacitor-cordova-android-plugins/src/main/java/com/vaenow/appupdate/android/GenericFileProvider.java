package com.vaenow.appupdate.android;

import android.support.v4.content.FileProvider;

/**
 * Created by kalea on 2017/8/23.
 */

public class GenericFileProvider extends FileProvider {

}
