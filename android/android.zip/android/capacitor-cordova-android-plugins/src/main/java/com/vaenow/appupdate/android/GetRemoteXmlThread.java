package com.vaenow.appupdate.android;

/**
 * Created by LuoWen on 2015/10/27.
 */
public class GetRemoteXmlThread extends Thread {

}
