package com.vaenow.appupdate.android;

/**
 * Created by Administrator on 2016/1/20.
 */
public class UIValues {
    private String updateLatest;
    private String updateTitle;
    private String updateMessage;
    private String updateUpdateBtn;
    private String updating;
    private String updateCancel;
    private String updateErrorTitle;
    private String updateErrorMessage;
    private String updateErrorYesBtn;

    public String getUpdateLatest() {
        return updateLatest;
    }

    public void setUpdateLatest(String updateLatest) {
        this.updateLatest = updateLatest;
    }

    public String getUpdateTitle() {
        return updateTitle;
    }

    public void setUpdateTitle(String updateTitle) {
        this.updateTitle = updateTitle;
    }

    public String getUpdateMessage() {
        return updateMessage;
    }

    public void setUpdateMessage(String updateMessage) {
        this.updateMessage = updateMessage;
    }

    public String getUpdateUpdateBtn() {
        return updateUpdateBtn;
    }

    public void setUpdateUpdateBtn(String updateUpdateBtn) {
        this.updateUpdateBtn = updateUpdateBtn;
    }

    public String getUpdating() {
        return updating;
    }

    public void setUpdating(String updating) {
        this.updating = updating;
    }

    public String getUpdateCancel() {
        return updateCancel;
    }

    public void setUpdateCancel(String updateCancel) {
        this.updateCancel = updateCancel;
    }

    public String getUpdateErrorTitle() {
        return updateErrorTitle;
    }

    public void setUpdateErrorTitle(String updateErrorTitle) {
        this.updateErrorTitle = updateErrorTitle;
    }

    public String getUpdateErrorMessage() {
        return updateErrorMessage;
    }

    public void setUpdateErrorMessage(String updateErrorMessage) {
        this.updateErrorMessage = updateErrorMessage;
    }

    public String getUpdateErrorYesBtn() {
        return updateErrorYesBtn;
    }

    public void setUpdateErrorYesBtn(String updateErrorYesBtn) {
        this.updateErrorYesBtn = updateErrorYesBtn;
    }
}
